package com.dicoding.projecttest.session

data class DataModel(
    var token: String,
    var id: String
)